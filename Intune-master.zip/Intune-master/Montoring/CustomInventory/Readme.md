Inventory Proactive Remediations scripts are moved to a new home: 
https://github.com/MSEndpointMgr/IntuneEnhancedInventory/tree/main/Proactive%20Remediation

The files in this folder is deprecated
