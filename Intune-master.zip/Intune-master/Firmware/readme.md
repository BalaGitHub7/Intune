# Intune Firmware related content 

### BIOSUpdate_PR 
This folder contains the proactive remediations for Intune BIOS update control. 
Current release is considered beta and have only support for HP 

### CustomInventory_PR
This folder contains our latest version of the Custom Inventory Script. Required for Intune BIOS update control. 

### HPMCSL_PR
This folder contains a Proactive Remediation package to keep HP CMSL powershell modules up to date. Required for Intune BIOS Update control for HP
