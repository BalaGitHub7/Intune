# Azure Function for Log Analytics data injection
## Keeping secrets out of code. 
