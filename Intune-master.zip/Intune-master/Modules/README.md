# PSIntuneAuth
Provides a function to retrieve an authentication token for Intune Graph API calls.

![PowerShell Gallery](https://img.shields.io/powershellgallery/dt/PSIntuneAuth)
