# Azure AD scripts

Scripts for Azure AD configuration:

* `Import-EntraDynamicGroup.ps1` - import a set of Azure AD dynamic device groups from a CSV file
* `Export-StateDevices.ps1` - List users and devices including last login time stamp
