# Windows 10 Kiosk

Windows 10 Kiosk configuration via an OMA-URI policy, where the Intune UI does not yet support all options.

```xml
AssignedAccess/Configuration
Assigns the kiosk mode configuration XML
./Device/Vendor/MSFT/AssignedAccess/Configuration
```
