# Intune scripts

Various scripts for use with devices managed Microsoft Endpoint Manager / Intune.

Also see the [proactive-remediations](https://github.com/aaronparker/proactive-remediations) repository for scripts to use with Endpoint Analytics [Proactive Remediations](https://learn.microsoft.com/en-us/mem/analytics/proactive-remediations).
